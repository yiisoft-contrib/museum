<?php

// include Yii bootstrap file
require_once(dirname(__FILE__).'/framework/yiilite.php');

// create a Web application instance and run
Yii::createWebApplication()->run();