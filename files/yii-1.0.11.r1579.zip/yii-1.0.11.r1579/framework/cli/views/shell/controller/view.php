This is the view content for action "<?php echo '<?php'; ?> echo $this->action->id; ?>" of controller "<?php echo '<?php'; ?> echo $this->id; ?>".
<br />You may customize this view by editing the file "<?php echo '<?php'; ?> echo __FILE__; ?>".
