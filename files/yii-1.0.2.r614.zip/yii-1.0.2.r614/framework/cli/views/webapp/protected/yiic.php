<?php

// change the following paths if necessary
$yiic='{YiicPath}';
$config=dirname(__FILE__).'/config/console.php';

require_once($yiic);
