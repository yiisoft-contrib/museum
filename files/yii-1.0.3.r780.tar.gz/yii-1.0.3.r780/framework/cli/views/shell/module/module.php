<?php echo "<?php\n"; ?>

class <?php echo $moduleClass; ?> extends CWebModule
{
	public function init($config)
	{
		parent::init($config);
		// this method is called when the module is being created
		// you may place code here to customize the module or the application
	}
}
