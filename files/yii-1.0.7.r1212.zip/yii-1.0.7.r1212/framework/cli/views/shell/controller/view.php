This is the view content for action "<?php echo $this->action->id; ?>" of controller "<?php echo $this->id; ?>".
<br />You may customize this view by editing the file "<?php echo __FILE__; ?>".
