<?php
/**
 * Copyright © 1991-2007 Unicode, Inc. All rights reserved.
 * Distributed under the Terms of Use in http://www.unicode.org/copyright.html.
 *
 * Copyright © 2008 Yii Software LLC (http://www.yiiframework.com/license/)
 */
return array (
  'version' => '1.48',
  'numberSymbols' => 
  array (
    'decimal' => ',',
    'group' => ' ',
    'list' => ';',
    'percentSign' => '%',
    'nativeZeroDigit' => '0',
    'patternDigit' => '#',
    'plusSign' => '+',
    'minusSign' => '-',
    'exponential' => 'E',
    'perMille' => '‰',
    'infinity' => '∞',
    'nan' => 'NaN',
  ),
  'decimalFormat' => '#,##0.###',
  'scientificFormat' => '#E0',
  'percentFormat' => '#,##0%',
  'currencyFormat' => '¤#,##0.00',
  'currencySymbols' => 
  array (
    'BRL' => 'R$',
    'EUR' => '€',
    'GBP' => 'UK£',
    'INR' => '0≤Rs.|1≤Re.|1<Rs.',
    'ITL' => 'IT₤',
    'JPY' => 'JP¥',
    'USD' => 'US$',
    'ZAR' => 'R',
  ),
  'monthNames' => 
  array (
    'wide' => 
    array (
      1 => 'Januarie',
      2 => 'Februarie',
      3 => 'Maart',
      4 => 'April',
      5 => 'Mei',
      6 => 'Junie',
      7 => 'Julie',
      8 => 'Augustus',
      9 => 'September',
      10 => 'Oktober',
      11 => 'November',
      12 => 'Desember',
    ),
    'abbreviated' => 
    array (
      1 => 'Jan',
      2 => 'Feb',
      3 => 'Mar',
      4 => 'Apr',
      5 => 'Mei',
      6 => 'Jun',
      7 => 'Jul',
      8 => 'Aug',
      9 => 'Sep',
      10 => 'Okt',
      11 => 'Nov',
      12 => 'Des',
    ),
    'narrow' => 
    array (
      1 => '1',
      2 => '2',
      3 => '3',
      4 => '4',
      5 => '5',
      6 => '6',
      7 => '7',
      8 => '8',
      9 => '9',
      10 => '10',
      11 => '11',
      12 => '12',
    ),
  ),
  'weekDayNames' => 
  array (
    'wide' => 
    array (
      0 => 'Sondag',
      1 => 'Maandag',
      2 => 'Dinsdag',
      3 => 'Woensdag',
      4 => 'Donderdag',
      5 => 'Vrydag',
      6 => 'Saterdag',
    ),
    'abbreviated' => 
    array (
      0 => 'So',
      1 => 'Ma',
      2 => 'Di',
      3 => 'Wo',
      4 => 'Do',
      5 => 'Vr',
      6 => 'Sa',
    ),
    'narrow' => 
    array (
      'sun' => '1',
      'mon' => '2',
      'tue' => '3',
      'wed' => '4',
      'thu' => '5',
      'fri' => '6',
      'sat' => '7',
    ),
  ),
  'eraNames' => 
  array (
    'abbreviated' => 
    array (
      0 => 'v.C.',
      1 => 'n.C.',
    ),
    'wide' => 
    array (
      0 => 'voor Christus',
      1 => 'na Christus',
    ),
    'narrow' => 
    array (
      0 => 'v.C.',
      1 => 'n.C.',
    ),
  ),
  'dateFormats' => 
  array (
    'full' => 'EEEE dd MMMM yyyy',
    'long' => 'dd MMMM yyyy',
    'medium' => 'dd MMM yyyy',
    'short' => 'yyyy/MM/dd',
  ),
  'timeFormats' => 
  array (
    'full' => 'h:mm:ss a v',
    'long' => 'h:mm:ss a z',
    'medium' => 'h:mm:ss a',
    'short' => 'h:mm a',
  ),
  'dateTimeFormat' => '{1} {0}',
  'amName' => 'vm.',
  'pmName' => 'nm.',
);
?>