<?php
/**
 * Copyright © 1991-2007 Unicode, Inc. All rights reserved.
 * Distributed under the Terms of Use in http://www.unicode.org/copyright.html.
 *
 * Copyright © 2008 Yii Software LLC (http://www.yiiframework.com/license/)
 */
return array (
  'version' => '1.46',
  'numberSymbols' => 
  array (
    'decimal' => ',',
    'group' => '.',
    'list' => ';',
    'percentSign' => '%',
    'nativeZeroDigit' => '0',
    'patternDigit' => '#',
    'plusSign' => '+',
    'minusSign' => '-',
    'exponential' => 'E',
    'perMille' => '‰',
    'infinity' => '∞',
    'nan' => 'NaN',
  ),
  'decimalFormat' => '#,##0.###',
  'scientificFormat' => '#E0',
  'percentFormat' => '#,##0%',
  'currencyFormat' => '¤#,##0.00;¤-#,##0.00',
  'currencySymbols' => 
  array (
    'BRL' => 'R$',
    'EUR' => '€',
    'GBP' => 'UK£',
    'INR' => '0≤Rs.|1≤Re.|1<Rs.',
    'ITL' => 'IT₤',
    'JPY' => 'JP¥',
    'USD' => 'US$',
    'DKK' => 'kr',
  ),
  'monthNames' => 
  array (
    'wide' => 
    array (
      1 => 'januari',
      2 => 'februari',
      3 => 'martsi',
      4 => 'aprili',
      5 => 'maji',
      6 => 'juni',
      7 => 'juli',
      8 => 'augustusi',
      9 => 'septemberi',
      10 => 'oktoberi',
      11 => 'novemberi',
      12 => 'decemberi',
    ),
    'abbreviated' => 
    array (
      1 => 'jan',
      2 => 'feb',
      3 => 'mar',
      4 => 'apr',
      5 => 'maj',
      6 => 'jun',
      7 => 'jul',
      8 => 'aug',
      9 => 'sep',
      10 => 'okt',
      11 => 'nov',
      12 => 'dec',
    ),
    'narrow' => 
    array (
      1 => '1',
      2 => '2',
      3 => '3',
      4 => '4',
      5 => '5',
      6 => '6',
      7 => '7',
      8 => '8',
      9 => '9',
      10 => '10',
      11 => '11',
      12 => '12',
    ),
  ),
  'weekDayNames' => 
  array (
    'wide' => 
    array (
      0 => 'sabaat',
      1 => 'ataasinngorneq',
      2 => 'marlunngorneq',
      3 => 'pingasunngorneq',
      4 => 'sisamanngorneq',
      5 => 'tallimanngorneq',
      6 => 'arfininngorneq',
    ),
    'abbreviated' => 
    array (
      0 => 'sab',
      1 => 'ata',
      2 => 'mar',
      3 => 'pin',
      4 => 'sis',
      5 => 'tal',
      6 => 'arf',
    ),
    'narrow' => 
    array (
      'sun' => '1',
      'mon' => '2',
      'tue' => '3',
      'wed' => '4',
      'thu' => '5',
      'fri' => '6',
      'sat' => '7',
    ),
  ),
  'eraNames' => 
  array (
    'abbreviated' => 
    array (
      0 => 'BCE',
      1 => 'CE',
    ),
    'wide' => 
    array (
      0 => 'BCE',
      1 => 'CE',
    ),
    'narrow' => 
    array (
      0 => 'BCE',
      1 => 'CE',
    ),
  ),
  'dateFormats' => 
  array (
    'full' => 'EEEE dd MMMM yyyy',
    'long' => 'dd MMMM yyyy',
    'medium' => 'MMM dd, yyyy',
    'short' => 'dd/MM/yy',
  ),
  'timeFormats' => 
  array (
    'full' => 'h:mm:ss a v',
    'long' => 'h:mm:ss a z',
    'medium' => 'h:mm:ss a',
    'short' => 'h:mm a',
  ),
  'dateTimeFormat' => '{1} {0}',
  'amName' => 'AM',
  'pmName' => 'PM',
);
?>