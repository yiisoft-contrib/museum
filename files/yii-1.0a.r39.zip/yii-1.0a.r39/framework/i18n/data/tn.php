<?php
/**
 * Copyright © 1991-2007 Unicode, Inc. All rights reserved.
 * Distributed under the Terms of Use in http://www.unicode.org/copyright.html.
 *
 * Copyright © 2008 Yii Software LLC (http://www.yiiframework.com/license/)
 */
return array (
  'version' => '1.22',
  'numberSymbols' => 
  array (
    'decimal' => ',',
    'group' => ' ',
    'list' => ';',
    'percentSign' => '%',
    'nativeZeroDigit' => '0',
    'patternDigit' => '#',
    'plusSign' => '+',
    'minusSign' => '-',
    'exponential' => 'E',
    'perMille' => '‰',
    'infinity' => '∞',
    'nan' => 'NaN',
  ),
  'decimalFormat' => '#,##0.###',
  'scientificFormat' => '#E0',
  'percentFormat' => '#,##0%',
  'currencyFormat' => '¤#,##0.00',
  'currencySymbols' => 
  array (
    'BRL' => 'R$',
    'EUR' => '€',
    'GBP' => 'UK£',
    'INR' => '0≤Rs.|1≤Re.|1<Rs.',
    'ITL' => 'IT₤',
    'JPY' => 'JP¥',
    'USD' => 'US$',
    'ZAR' => 'R',
  ),
  'monthNames' => 
  array (
    'wide' => 
    array (
      1 => 'Ferikgong',
      2 => 'Tlhakole',
      3 => 'Mopitlo',
      4 => 'Moranang',
      5 => 'Motsheganang',
      6 => 'Seetebosigo',
      7 => 'Phukwi',
      8 => 'Phatwe',
      9 => 'Lwetse',
      10 => 'Diphalane',
      11 => 'Ngwanatsele',
      12 => 'Sedimonthole',
    ),
    'abbreviated' => 
    array (
      1 => 'Fer',
      2 => 'Tlh',
      3 => 'Mop',
      4 => 'Mor',
      5 => 'Mot',
      6 => 'See',
      7 => 'Phu',
      8 => 'Pha',
      9 => 'Lwe',
      10 => 'Dip',
      11 => 'Ngw',
      12 => 'Sed',
    ),
    'narrow' => 
    array (
      1 => '1',
      2 => '2',
      3 => '3',
      4 => '4',
      5 => '5',
      6 => '6',
      7 => '7',
      8 => '8',
      9 => '9',
      10 => '10',
      11 => '11',
      12 => '12',
    ),
  ),
  'weekDayNames' => 
  array (
    'wide' => 
    array (
      0 => 'Tshipi',
      1 => 'Mosopulogo',
      2 => 'Labobedi',
      3 => 'Laboraro',
      4 => 'Labone',
      5 => 'Labotlhano',
      6 => 'Matlhatso',
    ),
    'abbreviated' => 
    array (
      0 => 'Tsh',
      1 => 'Mos',
      2 => 'Bed',
      3 => 'Rar',
      4 => 'Ne',
      5 => 'Tla',
      6 => 'Mat',
    ),
    'narrow' => 
    array (
      'sun' => '1',
      'mon' => '2',
      'tue' => '3',
      'wed' => '4',
      'thu' => '5',
      'fri' => '6',
      'sat' => '7',
    ),
  ),
  'eraNames' => 
  array (
    'abbreviated' => 
    array (
      0 => 'BC',
      1 => 'AD',
    ),
    'wide' => 
    array (
      0 => 'BC',
      1 => 'AD',
    ),
    'narrow' => 
    array (
      0 => 'BC',
      1 => 'AD',
    ),
  ),
  'dateFormats' => 
  array (
    'full' => 'EEEE, yyyy MMMM dd',
    'long' => 'yyyy MMMM d',
    'medium' => 'yyyy MMM d',
    'short' => 'yy/MM/dd',
  ),
  'timeFormats' => 
  array (
    'full' => 'HH:mm:ss v',
    'long' => 'HH:mm:ss z',
    'medium' => 'HH:mm:ss',
    'short' => 'HH:mm',
  ),
  'dateTimeFormat' => '{1} {0}',
  'amName' => 'AM',
  'pmName' => 'PM',
);
?>