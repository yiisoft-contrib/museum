This is the view content for action "<?php echo $this->action->id; ?>".
You may customize it by editing <tt><?php echo __FILE__; ?></tt>
