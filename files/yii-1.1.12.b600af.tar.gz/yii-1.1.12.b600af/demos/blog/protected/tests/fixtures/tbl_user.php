<?php

return array(
	array(
		'username'=>'demo',
		'password'=>'2e5c7db760a33498023813489cfadc0b',
		'salt'=>'28b206548469ce62182048fd9cf91760',
		'email'=>'webmaster@example.com',
	),
);
